extends Node2D

const W = 1280.0
const H = 720.0
const GROUND = 480.0
const WORLD = 3600.0
const COLORS = [Color("ed4d4d"), Color("469cff"), Color("ffd34e"), Color("49d87c")]
const NAMES = ["VERMELHO", "AZUL", "AMARELO", "VERDE"]
const GUNS = [
 {"name":"Pistola", "damage":24.0, "rate":0.35, "clip":12, "reload":1.1, "speed":780.0, "count":1, "color":Color("ffe88a")},
 {"name":"Metralhadora", "damage":12.0, "rate":0.10, "clip":35, "reload":1.7, "speed":900.0, "count":1, "color":Color("ffce62")},
 {"name":"Escopeta", "damage":14.0, "rate":0.65, "clip":8, "reload":1.5, "speed":690.0, "count":4, "color":Color("ffe1aa")},
 {"name":"Rifle", "damage":55.0, "rate":0.8, "clip":6, "reload":1.7, "speed":1100.0, "count":1, "color":Color("fff5bd")},
 {"name":"Arma de água", "damage":8.0, "rate":0.12, "clip":40, "reload":1.5, "speed":550.0, "count":1, "color":Color("5de3ff")},
 {"name":"Lança-chamas", "damage":9.0, "rate":0.09, "clip":45, "reload":2.0, "speed":450.0, "count":1, "color":Color("ff692f")},
 {"name":"Revólver", "damage":40.0, "rate":0.48, "clip":6, "reload":1.4, "speed":850.0, "count":1, "color":Color("fff09a")},
 {"name":"Bazuca — indisponível", "disabled":true}]
var state = "menu"
var count = 1
var choosing = 0
var selections = []
var players = []
var zombies = []
var bullets = []
var flashes = []
var corpses = []
var barrels = []
var touches = {}
var wave = 1
var spawned = 0
var wave_total = 0
var spawn_timer = 0.0
var wave_timer = 0.0
var camera = 0.0
var score = 0
var clock = 0.0
var volume = 0.6
var muted = false
var rng = RandomNumberGenerator.new()
var music: AudioStreamPlayer
var sound: AudioStreamPlayer

func _ready():
 rng.randomize()
 music = AudioStreamPlayer.new()
 sound = AudioStreamPlayer.new()
 add_child(music)
 add_child(sound)
 music.stream = make_music()
 music.volume_db = linear_to_db(volume * 0.24)
 music.play()

func make_music():
 var stream = AudioStreamWAV.new()
 var hz = 22050
 var duration = 4.0
 var data = PackedByteArray()
 data.resize(int(hz * duration) * 2)
 var notes = [110.0, 130.81, 146.83, 98.0, 110.0, 164.81, 146.83, 130.81]
 for i in range(int(hz * duration)):
  var t = float(i) / hz
  var beat = int(t * 2.0) % 8
  var env = exp(-fmod(t, 0.5) * 4.0)
  var sample = (sin(TAU * notes[beat] * t) * 0.22 + sin(TAU * notes[beat] * 2.0 * t) * 0.08) * env
  sample += sin(TAU * 55.0 * t) * 0.04
  var v = int(clamp(sample * 18000.0, -32767.0, 32767.0))
  data.encode_s16(i * 2, v)
 stream.format = AudioStreamWAV.FORMAT_16_BITS
 stream.mix_rate = hz
 stream.data = data
 stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
 stream.loop_end = int(hz * duration)
 return stream

func beep(freq = 440.0, seconds = 0.07):
 if muted or not is_instance_valid(sound): return
 var stream = AudioStreamWAV.new()
 var hz = 22050
 var samples = int(hz * seconds)
 var data = PackedByteArray()
 data.resize(samples * 2)
 for i in range(samples):
  var t = float(i) / hz
  data.encode_s16(i * 2, int(sin(TAU * freq * t) * 9000.0 * (1.0 - float(i) / samples)))
 stream.format = AudioStreamWAV.FORMAT_16_BITS
 stream.mix_rate = hz
 stream.data = data
 sound.stream = stream
 sound.volume_db = linear_to_db(max(0.001, volume))
 sound.play()

func update_volume():
 music.volume_db = -80.0 if muted or volume <= 0.0 else linear_to_db(volume * 0.24)

func start_game():
 players.clear()
 zombies.clear()
 bullets.clear()
 flashes.clear()
 corpses.clear()
 barrels.clear()
 for x in [360.0, 1050.0, 1840.0, 2600.0, 3260.0]:
  barrels.append({"x":x, "hp":35.0, "alive":true})
 touches.clear()
 score = 0
 wave = 1
 camera = 0.0
 for i in range(count):
  var gun = GUNS[selections[i]]
  players.append({"x":650.0 + i * 70.0, "hp":100.0, "gun":selections[i], "ammo":gun.clip, "cool":0.0, "reload":0.0, "dir":1, "dead":false, "kills":0, "height":0.0, "vy":0.0, "jump_held":false})
 state = "game"
 begin_wave()

func begin_wave():
 spawned = 0
 wave_total = 4 + wave * 3
 spawn_timer = 0.8
 wave_timer = 0.0

func spawn_zombie():
 var kind = 0
 var roll = rng.randf()
 if wave >= 2 and roll < 0.22: kind = 1
 if wave >= 3 and roll >= 0.22 and roll < 0.39: kind = 2
 if wave >= 4 and roll > 0.84: kind = 3
 var live = players.filter(func(p): return not p.dead)
 if live.is_empty(): return
 var target = live[rng.randi_range(0, live.size()-1)]
 var side = -1 if rng.randf() < 0.5 else 1
 var x = clamp(target.x + side * rng.randf_range(520.0, 800.0), 25.0, WORLD-25.0)
 var hp = [55.0, 72.0, 48.0, 220.0][kind] + (wave-1) * 7.0
 zombies.append({"x":x, "hp":hp, "maxhp":hp, "kind":kind, "cool":0.0, "hit":0.0})

func fire(i):
 var p = players[i]
 var gun = GUNS[p.gun]
 if p.dead or p.cool > 0.0 or p.reload > 0.0: return
 if p.ammo <= 0:
  p.reload = gun.reload
  return
 var nearest = null
 var dist = 99999.0
 for z in zombies:
  if abs(z.x - p.x) < dist:
   nearest = z
   dist = abs(z.x - p.x)
 if nearest != null: p.dir = 1 if nearest.x >= p.x else -1
 p.ammo -= 1
 p.cool = gun.rate
 for j in range(gun.count):
  bullets.append({"x":p.x + p.dir*24.0, "dir":p.dir, "speed":gun.speed * rng.randf_range(0.94,1.06), "life":0.35 if p.gun == 5 else (0.5 if p.gun == 2 else 1.35), "damage":gun.damage, "owner":i, "color":gun.color, "offset":(j-(gun.count-1)/2.0)*4.0})
 if p.ammo == 0: p.reload = gun.reload
 beep(180.0 if p.gun == 2 else 350.0, 0.045)

func controls_for(i):
 var result = {"move":0.0, "fire":false, "jump":false}
 for key in touches:
  var t = touches[key]
  if t.player != i: continue
  if t.action == "stick": result.move = t.value
  elif t.action == "fire": result.fire = true
  elif t.action == "jump": result.jump = true
 if i == 0:
  var keyboard_move = int(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)) - int(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT))
  if keyboard_move != 0: result.move = float(keyboard_move)
  result.fire = result.fire or Input.is_key_pressed(KEY_SPACE)
  result.jump = result.jump or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)
 return result

func update_stick(id, point):
 if not touches.has(id) or touches[id].action != "stick": return
 var t = touches[id]
 var zone = W/count
 var center = Vector2(t.player*zone + zone*0.22, 632.5)
 var radius = min(65.0, zone*0.19)
 var delta = (point-center).limit_length(radius)
 t.value = 0.0 if abs(delta.x) < radius*0.12 else clamp(delta.x/radius,-1.0,1.0)
 t.knob = delta

func _process(dt):
 dt = min(dt, 0.05)
 clock += dt
 if state != "game":
  queue_redraw()
  return
 for i in range(players.size()):
  var p = players[i]
  if p.dead: continue
  p.cool = max(0.0, p.cool-dt)
  if p.reload > 0.0:
   p.reload -= dt
   if p.reload <= 0.0:
    p.reload = 0.0
    p.ammo = GUNS[p.gun].clip
  var c = controls_for(i)
  var move = c.move
  if c.jump and not p.jump_held and p.height <= 0.0:
   p.vy = 430.0
  p.jump_held = c.jump
  if p.height > 0.0 or p.vy > 0.0:
   p.height = max(0.0, p.height + p.vy*dt)
   p.vy -= 1050.0*dt
   if p.height <= 0.0: p.vy = 0.0
  if move != 0:
   var low = 30.0
   var high = WORLD-30.0
   for other in players:
    if other != p and not other.dead:
     low = max(low, other.x - (W-180.0))
     high = min(high, other.x + (W-180.0))
   p.x = clamp(p.x + move * 185.0 * dt, low, high)
   p.dir = 1 if move > 0 else -1
  if c.fire: fire(i)
 var live = players.filter(func(p): return not p.dead)
 if live.is_empty():
  state = "defeat"
  touches.clear()
  queue_redraw()
  return
 var center = 0.0
 for p in live: center += p.x
 camera = clamp(center / live.size() - W/2.0, 0.0, WORLD-W)
 if spawned < wave_total:
  spawn_timer -= dt
  if spawn_timer <= 0:
   spawn_zombie()
   spawned += 1
   spawn_timer = max(0.35, 1.35 - wave * 0.13)
 for z in zombies:
  z.cool -= dt
  z.hit = max(0.0, z.hit-dt)
  var target = null
  var best = 99999.0
  for p in live:
   if abs(p.x-z.x) < best:
    target = p
    best = abs(p.x-z.x)
  if target == null: continue
  var direction = sign(target.x-z.x)
  var reach = 33.0 if z.kind != 1 else 52.0
  if best > reach:
   z.x += direction * [58.0, 75.0, 95.0, 37.0][z.kind] * (1.0+wave*0.045) * dt
  elif z.cool <= 0.0 and target.height < 45.0:
   if z.kind == 2:
    for p in live:
     if abs(p.x-z.x) < 115.0 and p.height < 45.0: p.hp -= 32.0
    flashes.append({"x":z.x,"life":0.3})
    z.hp = 0.0
    beep(90.0,0.2)
   else:
    target.hp -= [10.0, 16.0, 0.0, 22.0][z.kind]
    z.cool = [0.9, 0.95, 1.0, 1.3][z.kind]
    beep(130.0,0.08)
 for b in bullets:
  var previous = b.x
  b.x += b.dir*b.speed*dt
  b.life -= dt
  var victim = null
  var closest = 99999.0
  for z in zombies:
   var radius = 28.0 if z.kind == 3 else 18.0
   if z.hp > 0 and z.x >= min(previous,b.x)-radius and z.x <= max(previous,b.x)+radius and abs(z.x-previous) < closest:
    closest = abs(z.x-previous)
    victim = z
  # Barris recebem tiros e explodem, causando dano de área.
  var barrel_hit = null
  for barrel in barrels:
   if barrel.alive and barrel.x >= min(previous,b.x)-14 and barrel.x <= max(previous,b.x)+14:
    if victim == null or abs(barrel.x-previous) < closest:
     barrel_hit = barrel
     closest = abs(barrel.x-previous)
  if barrel_hit != null:
   barrel_hit.hp -= b.damage
   b.life = 0.0
   if barrel_hit.hp <= 0.0:
    barrel_hit.alive = false
    flashes.append({"x":barrel_hit.x,"life":0.3})
    beep(80.0,0.18)
    for z in zombies:
     if z.hp > 0.0 and abs(z.x-barrel_hit.x) < 130.0:
      z.hp -= 75.0
      z.hit = 0.12
      if z.hp <= 0.0:
       players[b.owner].kills += 1
       score += [100,150,180,350][z.kind]
       corpses.append({"x":z.x,"life":0.6})
    for p in players:
     if not p.dead and p.height < 45.0 and abs(p.x-barrel_hit.x) < 100.0: p.hp -= 20.0
  elif victim != null:
   victim.hp -= b.damage
   victim.hit = 0.12
   b.life = 0.0
   if victim.hp <= 0.0:
    players[b.owner].kills += 1
    score += [100,150,180,350][victim.kind]
    corpses.append({"x":victim.x,"life":0.6})
 bullets = bullets.filter(func(b): return b.life > 0.0 and b.x >= 0 and b.x <= WORLD)
 zombies = zombies.filter(func(z): return z.hp > 0.0)
 for p in players:
  if p.hp <= 0.0: p.dead = true
 for corpse in corpses: corpse.life -= dt
 corpses = corpses.filter(func(c): return c.life > 0.0)
 for f in flashes: f.life -= dt
 flashes = flashes.filter(func(f): return f.life > 0.0)
 if spawned >= wave_total and zombies.is_empty():
  wave_timer += dt
  if wave_timer > 2.0:
   if wave >= 5:
    state = "victory"
    touches.clear()
   else:
    wave += 1
    begin_wave()
 queue_redraw()

func rect_button(r, label, color=Color("344255"), font_size=24):
 draw_rect(r, color)
 draw_rect(r, Color("96a6b5"), false, 2.0)
 var font = ThemeDB.fallback_font
 var width = font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
 draw_string(font, Vector2(r.position.x + max(6.0,(r.size.x-width)/2.0), r.position.y+r.size.y/2.0+font_size*0.35), label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)

func text(pos, value, size=22, color=Color.WHITE):
 draw_string(ThemeDB.fallback_font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _draw():
 draw_rect(Rect2(0,0,W,H),Color("182333"))
 if state == "menu":
  text(Vector2(330,100+sin(clock*2.0)*5.0),"STICKMAN VS ZUMBIS",48,Color("ffdd75"))
  text(Vector2(350,150),"Sobreviva a 5 ondas na cidade abandonada",23)
  text(Vector2(390,225),"Escolha o número de jogadores locais:",25)
  for i in range(4): rect_button(Rect2(320+i*160,260,135,76),str(i+1), COLORS[i],36)
  rect_button(Rect2(440,390,400,70),"CONTINUAR",Color("3b805c"),28)
  text(Vector2(415,350),"Selecionados: %d" % count,22)
  draw_audio()
  return
 if state == "choose":
  text(Vector2(300,80),"ESCOLHA DE ARMAS",40,Color("ffdd75"))
  text(Vector2(300,125),"Jogador %d — %s" % [choosing+1,NAMES[choosing]],25,COLORS[choosing])
  for i in range(GUNS.size()):
   var r = Rect2(200+(i%2)*450,160+int(i/2)*82,420,65)
   rect_button(r,GUNS[i].name, Color("364354") if i != 7 else Color("43363c"),22)
  text(Vector2(300,520),"Toque numa arma. A escolha passa ao próximo jogador.",22)
  rect_button(Rect2(480,570,320,56),"VOLTAR AO MENU",Color("3b4858"),20)
  draw_audio()
  return
 if state == "ready":
  text(Vector2(380,150),"EQUIPE PRONTA!",44,Color("ffdd75"))
  for i in range(count): text(Vector2(380,220+i*35),"J%d %s — %s" % [i+1,NAMES[i],GUNS[selections[i]].name],24,COLORS[i])
  rect_button(Rect2(390,420,500,100),"JOGAR!",Color("3b805c"),40)
  rect_button(Rect2(480,550,320,56),"VOLTAR AO MENU",Color("3b4858"),20)
  draw_audio()
  return
 draw_city()
 for barrel in barrels:
  if barrel.alive:
   var bx = barrel.x-camera
   draw_rect(Rect2(bx-14,GROUND-34,28,34),Color("a85135"))
   draw_rect(Rect2(bx-14,GROUND-26,28,5),Color("e9b45a"))
   draw_rect(Rect2(bx-14,GROUND-8,28,4),Color("3b3432"))
 for i in range(players.size()):
  var p = players[i]
  draw_person(Vector2(p.x-camera,GROUND-i*3-p.height), COLORS[i], false, p.dead, p.dir, 1.0)
  text(Vector2(p.x-camera-20,GROUND-90-i*3-p.height),"J%d" % (i+1),16,COLORS[i])
 for z in zombies:
  var col = Color("b6f77b") if z.hit > 0 else [Color("8ba976"),Color("86ac8d"),Color("c59651"),Color("66865b")][z.kind]
  draw_person(Vector2(z.x-camera,GROUND+6),col,true,false,1,1.45 if z.kind == 3 else 1.0)
  var sx = z.x-camera
  draw_rect(Rect2(sx-25,GROUND-100,50,5),Color("4a1e22"))
  draw_rect(Rect2(sx-25,GROUND-100,50*max(0,z.hp)/z.maxhp,5),Color("e25a58"))
  if z.kind == 1: draw_line(Vector2(sx+15,GROUND-45),Vector2(sx+48,GROUND-80),Color("cdd4db"),5)
  if z.kind == 2: draw_circle(Vector2(sx+18,GROUND-35),9,Color("e5543b"))
 for corpse in corpses:
  var fall = 1.0 - corpse.life/0.6
  var cx = corpse.x-camera
  draw_line(Vector2(cx,GROUND-55*(1.0-fall)),Vector2(cx+fall*35,GROUND-10),Color("8ba976"),7)
  draw_circle(Vector2(cx,GROUND-55*(1.0-fall)),9,Color("8ba976"))
 for b in bullets:
  draw_circle(Vector2(b.x-camera,GROUND-48+b.offset),4.5,b.color)
 for f in flashes:
  var progress = 1.0-f.life/0.3
  var origin = Vector2(f.x-camera,GROUND-30)
  draw_circle(origin,65.0*progress,Color(1,0.4,0.1,0.5*(1.0-progress)))
  for particle in range(12):
   var angle = TAU*particle/12.0
   var offset = Vector2(cos(angle),sin(angle))*progress*(50.0+particle*4.0)
   draw_circle(origin+offset,3.0+3.0*(1.0-progress),Color(1,0.75,0.2,1.0-progress))
 text(Vector2(20,33),"ONDA %d/5   PONTOS: %d   INIMIGOS: %d" % [wave,score,zombies.size()+wave_total-spawned],23)
 rect_button(Rect2(1135,12,125,45),"PAUSA",Color("414f5e"),18)
 for i in range(players.size()):
  var p = players[i]
  var info = "J%d %s  VIDA %d  %s  %s" % [i+1,NAMES[i],max(0,int(p.hp)),GUNS[p.gun].name,"CAÍDO" if p.dead else ("RECARREGANDO" if p.reload>0 else "MUNIÇÃO %d" % p.ammo)]
  text(Vector2(20,65+i*23),info,17,COLORS[i])
 if state == "game": draw_controls()
 if state == "paused":
  draw_rect(Rect2(0,0,W,H),Color(0,0,0,0.68))
  text(Vector2(550,185),"PAUSA",42)
  rect_button(Rect2(440,220,400,70),"CONTINUAR",Color("3b805c"))
  rect_button(Rect2(440,310,400,70),"REINICIAR PARTIDA",Color("7c5642"))
  rect_button(Rect2(440,400,400,70),"MENU PRINCIPAL")
  draw_audio()
 if state == "victory" or state == "defeat":
  draw_rect(Rect2(0,0,W,H),Color(0,0,0,0.75))
  text(Vector2(445,200),"VITÓRIA!" if state == "victory" else "DERROTA!",50,Color("ffdd75"))
  text(Vector2(465,250),"Pontuação: %d" % score,30)
  rect_button(Rect2(430,300,420,70),"JOGAR NOVAMENTE",Color("3b805c"))
  rect_button(Rect2(430,390,420,70),"MENU PRINCIPAL")

func draw_audio():
 rect_button(Rect2(930,640,135,55),"SOM: OFF" if muted else "SOM: ON",Color("3e4e5d"),17)
 rect_button(Rect2(1070,640,70,55),"-",Color("3e4e5d"),24)
 rect_button(Rect2(1150,640,70,55),"+",Color("3e4e5d"),24)
 text(Vector2(995,630),"Volume %d%%" % int(volume*100),17)

func draw_city():
 draw_rect(Rect2(0,0,W,GROUND),Color("27384c"))
 draw_circle(Vector2(1050,100),45,Color("66737e"))
 for i in range(-1,20):
  var wx = i*230.0
  var x = wx - fmod(camera*0.42,230.0)
  var h = 140 + int(abs(i*71)%125)
  draw_colored_polygon(PackedVector2Array([Vector2(x,GROUND),Vector2(x,GROUND-h),Vector2(x+35,GROUND-h-20),Vector2(x+70,GROUND-h-5),Vector2(x+100,GROUND-h-35),Vector2(x+150,GROUND-h-10),Vector2(x+180,GROUND-h+15),Vector2(x+180,GROUND)]),Color("344251"))
  for row in range(4):
   for col in range(4): draw_rect(Rect2(x+15+col*38,GROUND-h+20+row*30,19,14),Color("586069") if (i+row+col)%3==0 else Color("252f3b"))
 draw_rect(Rect2(0,GROUND,W,240),Color("373c3b"))
 draw_rect(Rect2(0,GROUND,W,9),Color("777665"))
 for i in range(12):
  var x = i*180-fmod(camera,180.0)
  draw_line(Vector2(x,GROUND+48),Vector2(x+90,GROUND+48),Color("68695b"),5)

func draw_person(pos, color, zombie, dead, direction, scale_factor):
 var x = pos.x
 var y = pos.y
 var s = scale_factor
 if dead:
  draw_circle(Vector2(x-25,y-8),9*s,color)
  draw_line(Vector2(x-14,y-8),Vector2(x+28,y-8),color,7*s)
  return
 var swing = sin(clock*8+x*0.03)*8.0
 draw_circle(Vector2(x,y-70*s),10*s,color)
 draw_line(Vector2(x,y-60*s),Vector2(x,y-27*s),color,6*s)
 draw_line(Vector2(x,y-27*s),Vector2(x-13*s+swing,y),color,6*s)
 draw_line(Vector2(x,y-27*s),Vector2(x+13*s-swing,y),color,6*s)
 draw_line(Vector2(x,y-51*s),Vector2(x+direction*23*s,y-45*s),color,5*s)
 draw_line(Vector2(x,y-51*s),Vector2(x-direction*15*s,y-34*s),color,5*s)
 if not zombie: draw_line(Vector2(x+direction*18*s,y-46*s),Vector2(x+direction*30*s,y-46*s),Color("d0d7d7"),5)

func draw_controls():
 var zone = W/count
 for i in range(count):
  var x = i*zone
  var radius = min(65.0,zone*0.19)
  var center = Vector2(x+zone*0.22,632.5)
  draw_circle(center,radius,Color(COLORS[i],0.35))
  var knob = Vector2.ZERO
  for id in touches:
   if touches[id].player == i and touches[id].action == "stick": knob = touches[id].knob
  draw_circle(center+knob,radius*0.38,Color(COLORS[i],0.85))
  var btn_w = zone*0.26
  rect_button(Rect2(x+zone*0.45,565,btn_w,135),"PULAR",Color(COLORS[i],0.65),int(clamp(btn_w/4,12,23)))
  rect_button(Rect2(x+zone*0.73,565,btn_w-4,135),"ATIRAR",Color(COLORS[i],0.8),int(clamp(btn_w/4,12,23)))

func _input(event):
 if event is InputEventScreenTouch:
  if event.pressed: pointer_down(event.index,event.position)
  else: touches.erase(event.index)
 elif event is InputEventScreenDrag:
  update_stick(event.index,event.position)
 elif event is InputEventMouseMotion:
  update_stick(-1,event.position)
 elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
  if event.pressed: pointer_down(-1,event.position)
  else: touches.erase(-1)
 elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
  if state == "game": state = "paused"; touches.clear()
  elif state == "paused": state = "game"

func pointer_down(id, point):
 if state in ["menu","choose","ready","paused"] and point.y >= 640:
  if Rect2(930,640,135,55).has_point(point): muted = not muted; update_volume(); return
  if Rect2(1070,640,70,55).has_point(point): volume = max(0.0,volume-0.1); update_volume(); return
  if Rect2(1150,640,70,55).has_point(point): volume = min(1.0,volume+0.1); update_volume(); return
 if state == "menu":
  for i in range(4):
   if Rect2(320+i*160,260,135,76).has_point(point): count=i+1; return
  if Rect2(440,390,400,70).has_point(point): selections.clear(); choosing=0; state="choose"
 elif state == "choose":
  if Rect2(480,570,320,56).has_point(point): state="menu"; return
  for i in range(GUNS.size()):
   if Rect2(200+(i%2)*450,160+int(i/2)*82,420,65).has_point(point):
    if GUNS[i].has("disabled"): return
    selections.append(i)
    choosing += 1
    if choosing == count: state = "ready"
    return
 elif state == "ready":
  if Rect2(390,420,500,100).has_point(point): start_game()
  elif Rect2(480,550,320,56).has_point(point): state="menu"
 elif state == "game":
  if Rect2(1135,12,125,45).has_point(point): state="paused"; touches.clear(); return
  if point.y >= 565 and point.y < 700:
   var zone = W/count
   var i = clamp(int(point.x/zone),0,count-1)
   var local_x = point.x-i*zone
   if local_x < zone*0.44:
    touches[id] = {"player":i,"action":"stick","value":0.0,"knob":Vector2.ZERO}
    update_stick(id, point)
   elif local_x < zone*0.72:
    touches[id] = {"player":i,"action":"jump"}
   else:
    touches[id] = {"player":i,"action":"fire"}
 elif state == "paused":
  if Rect2(440,220,400,70).has_point(point): state="game"
  elif Rect2(440,310,400,70).has_point(point): start_game()
  elif Rect2(440,400,400,70).has_point(point): state="menu"
 elif state in ["victory","defeat"]:
  if Rect2(430,300,420,70).has_point(point): start_game()
  elif Rect2(430,390,420,70).has_point(point): state="menu"
