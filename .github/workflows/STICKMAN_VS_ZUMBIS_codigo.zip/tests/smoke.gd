extends SceneTree
var failures = 0
func check(ok, message):
 if ok: print("OK: ", message)
 else:
  failures += 1
  printerr("FAIL: ", message)
func _initialize():
 call_deferred("run")
func run():
 var game = load("res://main.tscn").instantiate()
 root.add_child(game)
 game.set_process(false)
 check(game.state == "menu", "menu inicial")
 game.pointer_down(0,Vector2(820,300))
 check(game.count == 4, "seleção de quatro jogadores")
 game.pointer_down(0,Vector2(500,420))
 check(game.state == "choose", "tela de armas")
 game.pointer_down(0,Vector2(700,420))
 check(game.selections.size() == 0, "bazuca indisponível")
 for pos in [Vector2(300,180), Vector2(700,180), Vector2(300,270), Vector2(700,270)]: game.pointer_down(0,pos)
 check(game.state == "ready" and game.selections.size()==4, "quatro seleções sequenciais")
 game.pointer_down(0,Vector2(600,470))
 check(game.state == "game" and game.players.size()==4, "botão jogar inicia partida")
 check(game.players[0].gun==0 and game.players[3].gun==3, "armas individuais")
 game.pointer_down(10,Vector2(30,632))
 game.pointer_down(11,Vector2(285,600))
 game.pointer_down(12,Vector2(400,632))
 game.pointer_down(13,Vector2(515,600))
 check(game.controls_for(0).move < 0 and game.controls_for(0).fire and game.controls_for(1).move > 0 and game.controls_for(1).jump, "analógicos e botões independentes")
 game.update_stick(10,Vector2(80,632))
 check(game.controls_for(0).move > 0, "arrastar analógico muda direção")
 game.touches.clear()
 game.pointer_down(20,Vector2(180,600))
 var before_jump = game.players[0].height
 game._process(0.05)
 check(game.players[0].height > before_jump, "pulo sai do chão")
 for n in range(30): game._process(0.05)
 check(game.players[0].height == 0.0, "pulo aterrissa sem repetir ao segurar")
 game.touches.clear()
 game.zombies.clear()
 var p = game.players[0]
 p.height = 70.0; p.vy = 0.0
 game.zombies = [{"x":p.x+20.0,"hp":55.0,"maxhp":55.0,"kind":0,"cool":0.0,"hit":0.0}]
 var airborne_hp = p.hp
 game._process(0.02)
 check(p.hp == airborne_hp, "pulo evita ataque no chão quando alto")
 p.height = 0.0; p.vy = 0.0
 game.zombies.clear()
 game.touches.clear()
 game.zombies = [{"x":p.x+65.0,"hp":20.0,"maxhp":20.0,"kind":0,"cool":3.0,"hit":0.0}]
 game.fire(0)
 check(p.ammo==11 and game.bullets.size()==1, "tiro consome munição")
 for n in range(10): game._process(0.02)
 check(game.score==100 and p.kills==1 and game.zombies.is_empty(), "projétil acerta, mata e pontua")
 p.ammo=1; p.cool=0.0; game.fire(0)
 check(p.reload>0.0, "recarga automática começa")
 for n in range(80): game._process(0.02)
 check(p.ammo==12 and p.reload==0.0, "recarga automática termina")
 game.spawned=game.wave_total
 game.zombies.clear()
 for n in range(110): game._process(0.02)
 check(game.wave==2, "progressão de onda")
 game.zombies=[{"x":p.x+20.0,"hp":48.0,"maxhp":48.0,"kind":2,"cool":0.0,"hit":0.0}]
 var hp = p.hp
 game._process(0.02)
 check(p.hp < hp and game.zombies.is_empty(), "explosão do zumbi bomba")
 game.zombies.clear()
 game.barrels = [{"x":p.x+80.0,"hp":1.0,"alive":true}]
 game.zombies=[{"x":p.x+110.0,"hp":50.0,"maxhp":50.0,"kind":0,"cool":10.0,"hit":0.0}]
 p.cool=0.0; p.reload=0.0; p.ammo=12
 var previous_score = game.score
 game.fire(0)
 for n in range(10): game._process(0.02)
 check(not game.barrels[0].alive and game.zombies.is_empty() and game.score==previous_score+100, "barril explosivo interativo causa dano e pontua")
 game.wave=5; game.spawned=game.wave_total; game.zombies.clear(); game.wave_timer=1.99
 game._process(0.05)
 check(game.state=="victory", "vitória após quinta onda")
 game.start_game()
 for player in game.players: player.hp=0; player.dead=true
 game._process(0.02)
 check(game.state=="defeat", "derrota quando todos caem")
 game.start_game()
 game.pointer_down(0,Vector2(1190,30))
 check(game.state=="paused", "pausa")
 game.pointer_down(0,Vector2(600,250))
 check(game.state=="game", "retomada")
 game.queue_free()
 await process_frame
 print("Falhas: ", failures)
 quit(1 if failures else 0)
