# STICKMAN VS ZUMBIS

Jogo 2D cooperativo local de sobrevivência, para 1 a 4 pessoas na mesma tela, feito com Godot 4.3 estável e GDScript. Não exige internet durante a partida. Código, ilustrações vetoriais e áudio são originais e gerados pelo programa, sem pacotes pagos.

## Como jogar

Coloque o celular na horizontal. No menu, escolha de 1 a 4 jogadores e toque em **CONTINUAR**. Cada pessoa escolhe uma arma, na ordem: vermelho, azul, amarelo e verde. A bazuca aparece como indisponível e não pode ser selecionada. Após as escolhas, toque no botão grande **JOGAR!**. São sete armas jogáveis: pistola, metralhadora, escopeta, rifle, arma de água, lança-chamas e revólver, com cadências, danos e carregadores diferentes.

Na parte inferior, cada faixa colorida pertence a uma pessoa. Arraste o **analógico** colorido para andar (mais longe do centro = mais rápido), toque em **PULAR** para saltar e segure **ATIRAR** para disparar; vários dedos funcionam independentemente. Para saltar de novo, solte e toque novamente. Durante a parte alta do salto, ataques e explosões no chão não atingem o personagem; os disparos seguem no plano do chão. Cada jogador mira automaticamente no zumbi mais próximo. Ao esvaziar o carregador, a arma recarrega sozinha; a munição de reserva é ilimitada. A câmera acompanha o centro dos sobreviventes; jogadores não podem afastar-se além da largura segura da tela. Em telas pequenas, quatro pessoas podem ter dificuldade para tocar nos controles ao mesmo tempo. Para mover e atirar, são necessários até 8 toques simultâneos; para também pular, até 12. Muitos celulares aceitam menos e podem perder toques ou apresentar interferências. Os controles ficam na mesma borda da tela, não em lados opostos: quatro pessoas em um celular são uma opção experimental, sendo mais realista usar um tablet ou jogar com menos pessoas. Não há suporte implementado a controles externos para J2–J4.

Defenda-se por cinco ondas. Zumbis comuns, espadachins, bombas de dano em área e mutantes resistentes surgem progressivamente; pontos são ganhos por abates. Barris vermelhos podem ser destruídos com tiros: a explosão machuca zumbis e também jogadores próximos. Os jogadores caídos não voltam durante a partida. Todos caídos = derrota; limpar a quinta onda = vitória. Pause no canto superior direito para continuar, reiniciar ou voltar ao menu. Nas telas de menu, escolha de arma e pausa há controle de volume e silêncio. No computador, o jogador 1 pode usar A/D ou setas esquerda/direita, W ou seta para cima para pular, espaço para atirar e Esc para pausar, além do mouse.

O cenário é desenhado em camadas, com rolagem lateral; personagens são figuras de palito animadas. Música em loop e efeitos simples são sintetizados. A resolução interna é 1280×720, escalada para a tela com proporção preservada.

## Abrir e testar

1. Instale **Godot 4.3 estável** de https://godotengine.org/download/ e importe `project.godot`.
2. Execute com F6/F5. Também é possível executar o teste automatizado no terminal:

   ```sh
   godot --headless --path . --script res://tests/smoke.gd
   ```

O teste exercita menus, quatro escolhas, analógico, arrasto, salto, defesa durante o salto, toques independentes simulados, tiros, dano, recarga, onda, bomba, barril explosivo, vitória, derrota e pausa. Não substitui testes físicos de tela e áudio.

## Gerar e instalar APK localmente

1. Instale os templates de exportação da **mesma versão 4.3 estável** no Godot (Editor → Manage Export Templates).
2. Instale o OpenJDK 17 e Android SDK, configurando os caminhos em Editor Settings → Export → Android. Gere/configure uma chave **debug** conforme a documentação oficial: https://docs.godotengine.org/en/4.3/tutorials/export/exporting_for_android.html .
3. Em Project → Export, selecione `Android` e exporte como APK com `Export With Debug` marcado. Ou, após a configuração do editor:

   ```sh
   mkdir -p build
   godot --headless --path . --export-debug Android "$(pwd)/build/stickman-vs-zumbis-debug.apk"
   ```

4. Envie o APK ao aparelho Android e permita instalações da origem escolhida nas configurações do aparelho. Toque no APK para instalar, ou use `adb install -r build/stickman-vs-zumbis-debug.apk` com depuração USB autorizada. O APK debug é para testes, não para publicação em loja. Atualmente o identificador é `org.exemplo.stickmanvszumbis`: troque-o antes de publicar.

## GitHub Actions

A automação está incluída, mas **não foi executada** neste projeto. Para enviá-la a um repositório de sua conta, você pode usar Git no computador:

1. Crie um repositório vazio no GitHub, público ou privado conforme sua preferência, sem README nem licença iniciais.
2. Descompacte o ZIP e abra o terminal dentro da pasta que contém `project.godot` e `.github`. Arquivos iniciados com ponto podem ficar ocultos no gerenciador de arquivos.
3. Execute os comandos abaixo, substituindo a URL pela URL HTTPS do seu repositório. O GitHub pode solicitar autenticação pelo método configurado no seu computador; não coloque credenciais na URL.

   ```sh
   git init
   git add .
   git commit -m "Adicionar jogo Stickman vs Zumbis"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
   git push -u origin main
   ```

4. Abra o repositório no GitHub, vá em **Actions** → **Android debug APK**. O push deve iniciar uma execução; se necessário, abra o workflow e use **Run workflow**. Aguarde e entre na execução concluída.
5. Em **Artifacts**, baixe `stickman-vs-zumbis-debug`, descompacte e instale o APK no Android conforme a seção anterior. Se a execução falhar, consulte os logs de cada etapa; nenhum APK é fornecido aqui antecipadamente. Artifacts podem expirar conforme a configuração do GitHub.

O workflow usa a imagem comunitária gratuita `barichello/godot-ci:4.3`, com templates, SDK e configuração debug. O upload exige arquivo APK não vazio; disponibilidade e limites do GitHub Actions dependem da conta e do repositório. Nenhum serviço pago é necessário para testar localmente.

## Publicação de release

Para distribuir uma versão de produção, crie e guarde uma chave de assinatura release própria, configure o preset Android com essa chave fora do repositório e exporte o formato solicitado pela loja (normalmente AAB). Nunca publique a chave ou a senha no código. O workflow incluído gera apenas debug e não faz publicação. A assinatura release e os requisitos atuais da loja devem ser verificados antes do envio.

## Limitações e validação

Protótipo jogável: não tem modo online, salvar progresso, reanimação, menu de reconfiguração; jogabilidade em um plano horizontal com salto simplificado. O controle de volume e o mute valem até fechar o jogo. As colisões são calculadas por código e o design é simples. O projeto foi importado e iniciado em Godot 4.3 headless; o script incluído passou em 22 verificações. O motor emitiu aviso de objetos não liberados no encerramento do teste e da execução headless. Uma tentativa de exportação falhou porque faltavam templates Android, Java, SDK e chave debug neste ambiente; portanto nenhum APK foi produzido. O workflow do GitHub Actions ainda não foi testado. Não houve teste visual, de áudio ou em aparelho Android. O funcionamento real de multitouch, áudio, escala e instalação deve ser confirmado no aparelho.

Licença: MIT, veja `LICENSE`.
